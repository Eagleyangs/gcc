ddir = 'xx'
